1;
CHANGE
1,
		return (int) Math.signum(first.area() - second.area());
1,
		return (int) Math.signum(first.area() + second.area());
