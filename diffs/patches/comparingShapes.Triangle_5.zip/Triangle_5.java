1;
CHANGE
2,
		throw new UnsupportedOperationException("TODO: delete this statement and implement this operation.");

2,
		double s = (a+b+c)/2;
		return Math.sqrt(s*(s-a)*(s-b)*(s-c));
